/*
 * emu_sc_channel_drv_slib_v1.h
 *
 *  Created on: Dec 20, 2016
 *      Author: user
 */

#ifndef EMU_SC_CHANNEL_DRV_SLIB_V1_H_
#define EMU_SC_CHANNEL_DRV_SLIB_V1_H_

#include <public/sc_channel_drv_v1.h>


#endif /* EMU_SC_CHANNEL_DRV_SLIB_V1_H_ */
